package edu.tacoma.uw.set.css.dpeevy.uwleonapp;
// no changes

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class AboutLeonPage extends AppCompatActivity {


    // borrowed & modified from GFG: https://www.geeksforgeeks.org/exposed-drop-down-menu-in-android/
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.about_leon_page);

            // get reference to the string array that we just created
            String[] art_history = getResources().getStringArray(R.array.art_history);
            // create an array adapter and pass the required parameters
            // in our case pass the context, drop down layout , and array.
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.dropdown_item, art_history);
            // get reference to the autocomplete text view
            AutoCompleteTextView autocompleteTV = findViewById(R.id.autoCompleteTextView);
            // set adapter to the autocomplete tv to the arrayAdapter
            autocompleteTV.setAdapter(arrayAdapter);
            // get reference to the string array that we just created


            String[] intellectual_history = getResources().getStringArray(R.array.intellectual_history);
            // create an array adapter and pass the required parameters
            // in our case pass the context, drop down layout , and array.
            ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<>(this, R.layout.dropdown_item2, intellectual_history);
            // get reference to the autocomplete text view
            AutoCompleteTextView autocompleteTV2 = findViewById(R.id.autoCompleteTextView2);
            // set adapter to the autocomplete tv to the arrayAdapter
            autocompleteTV2.setAdapter(arrayAdapter2);

//            "Welcome to the About page\n"
//                    "This is the About Page.\n"
//                    "     \tHighlights:\n"
//                    "     \tArt History\n"
//                    "           \t-Architecture\n"
//                    "           \t-Catholic Art\n"
//                    "     \tIntellectual History\n"
//                    "           \t-Astronauts\n"
//                    "           \t-Cyber Security Center\n"
//                    "     \tContemporary\n"
//                    "           \t-Bars and parties"

        }
}